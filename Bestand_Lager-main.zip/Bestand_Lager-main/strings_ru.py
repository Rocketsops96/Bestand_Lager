
strings = {
"home_button_text": "Главная",
    "frame_2_button_text": "Стройка",
    "frame_3_button_text": "Редактор",
    }