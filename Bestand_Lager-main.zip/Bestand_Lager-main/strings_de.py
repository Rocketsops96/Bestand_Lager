strings = {
"home_button_text": "Startseite",
    "frame_2_button_text": "Baustelle",
    "frame_3_button_text": "Editor",
    }